//: [Previous](@previous)
/*:
## Functions without Params
*/
// defining the "sayHello" function
func sayHello() {
    print("Hello!")
}

// called "sayHello"
sayHello()
//: [Next](@next)
