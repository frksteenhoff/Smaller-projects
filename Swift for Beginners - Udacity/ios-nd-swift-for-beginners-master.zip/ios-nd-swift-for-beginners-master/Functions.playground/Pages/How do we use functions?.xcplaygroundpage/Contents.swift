//: [Previous](@previous)
/*:
## You've Been Using Functions
*/
// we've seen the "print" function before
print("I'm calling a function!")

//: [Next](@next)
