//: [Previous](@previous)

//:If Statements Exercise 1a: The Bouncer

// Here are some variables to represents a person who wants to come into a club

var name = "Gabrielle"
var age = 29
var onGuestList = true

func admit(person: String) {
    print("\(person), come and party with us!")
}

func deny(person: String) {
    print("Sorry, \(person), maybe you can go play Bingo with the Android team.")
}

func screen(onGuestList: Bool, person: String) {
    // TODO: Add your if statement here!
}

//: [Next](@next)
