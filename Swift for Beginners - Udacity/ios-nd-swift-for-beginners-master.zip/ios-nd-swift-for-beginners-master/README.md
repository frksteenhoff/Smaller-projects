<img src="https://s3-us-west-1.amazonaws.com/udacity-content/degrees/catalog-images/nd003.png" alt="iOS Developer Nanodegree logo" height="70" >

# Swift for Beginners (and Swift Problem Set)

![Platform iOS](https://img.shields.io/badge/nanodegree-iOS-blue.svg)

This repository contains starter code for the Swift for Beginners course and project in Udacity's iOS Nanodegree.

## Maintainers

@GabrielleM
